
"use client";

import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export function DJIChart() {
  return (
    <Card className="bg-white/60 backdrop-blur-sm border-slate-200">
      <CardHeader>
        <CardTitle>Dow Jones Industrial Average (DJI)</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="w-full h-[500px]">
          <iframe
            src="https://s.tradingview.com/widgetembed/?frameElementId=tradingview_dji&symbol=DJI&interval=D&hidesidetoolbar=1&symboledit=1&saveimage=1&toolbarbg=f1f3f6&studies=[]&theme=light&style=1&timezone=Etc/UTC&withdateranges=1&hidevolume=1&hidelegend=0&logscale=1&hide_side_toolbar=0&allow_symbol_change=1&details=1&hotlist=1&calendar=1&show_popup_button=1&popup_width=1000&popup_height=650"
            width="100%"
            height="100%"
            frameBorder="0"
            allowTransparency
            scrolling="no"
            allowFullScreen
            title="DJI Chart"
          ></iframe>
        </div>
      </CardContent>
    </Card>
  );
}
